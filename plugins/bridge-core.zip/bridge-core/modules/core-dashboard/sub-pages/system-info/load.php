<?php

include_once BRIDGE_CORE_MODULES_PATH . '/core-dashboard/sub-pages/system-info/system-info.php';